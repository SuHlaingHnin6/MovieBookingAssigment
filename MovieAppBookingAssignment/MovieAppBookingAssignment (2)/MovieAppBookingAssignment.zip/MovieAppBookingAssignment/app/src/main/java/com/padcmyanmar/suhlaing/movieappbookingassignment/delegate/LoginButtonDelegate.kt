package com.padcmyanmar.suhlaing.movieappbookingassignment.delegate

interface LoginButtonDelegate {
    fun onTapComfirm()
}