package com.padcmyanmar.suhlaing.movieappbookingassignment.viewholder

import android.view.View
import androidx.recyclerview.widget.RecyclerView

class ChipMovieDetailViewHolder(itemView:View):RecyclerView.ViewHolder(itemView) {
}