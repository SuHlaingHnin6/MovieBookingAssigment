package com.padcmyanmar.suhlaing.movieappbookingassignment.viewpod

import android.content.Context
import android.util.AttributeSet
import android.widget.RelativeLayout

class ViewPodLogin @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : RelativeLayout(context, attrs) {

}