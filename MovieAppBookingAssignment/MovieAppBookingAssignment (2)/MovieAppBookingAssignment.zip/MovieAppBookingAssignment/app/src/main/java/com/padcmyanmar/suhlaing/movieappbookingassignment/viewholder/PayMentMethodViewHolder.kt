package com.padcmyanmar.suhlaing.movieappbookingassignment.viewholder

import android.view.View
import androidx.appcompat.view.menu.ActionMenuItemView
import androidx.recyclerview.widget.RecyclerView

class PayMentMethodViewHolder(itemView: View):RecyclerView.ViewHolder(itemView) {
}