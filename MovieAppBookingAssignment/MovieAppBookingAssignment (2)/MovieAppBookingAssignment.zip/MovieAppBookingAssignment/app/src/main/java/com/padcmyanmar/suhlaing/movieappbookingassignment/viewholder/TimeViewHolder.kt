package com.padcmyanmar.suhlaing.movieappbookingassignment.viewholder

import android.view.View
import androidx.recyclerview.widget.RecyclerView

class TimeViewHolder(itenView:View):RecyclerView.ViewHolder(itenView) {
}