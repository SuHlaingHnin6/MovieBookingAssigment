package com.padcmyanmar.suhlaing.movieappbookingassignment.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.tabs.TabLayoutMediator
import com.padcmyanmar.suhlaing.movieappbookingassignment.R
import com.padcmyanmar.suhlaing.movieappbookingassignment.adapter.DifferentScreenViewPagerAdapter
import com.padcmyanmar.suhlaing.movieappbookingassignment.delegate.LoginButtonDelegate
import kotlinx.android.synthetic.main.activity_login_page.*
import kotlinx.android.synthetic.main.login_view_pod.*

class LoginPageActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_page)

        val differentScreenViewPagerAdapter = DifferentScreenViewPagerAdapter(this)
        viewPagerDifferentScreen.adapter = differentScreenViewPagerAdapter


        TabLayoutMediator(tabScreen, viewPagerDifferentScreen){tab,position->
            when(position){
                0->{
                    tab.text = "Login"
                }
                else->{
                    tab.text = "Signin"
                }
            }

        }.attach()



    }

}