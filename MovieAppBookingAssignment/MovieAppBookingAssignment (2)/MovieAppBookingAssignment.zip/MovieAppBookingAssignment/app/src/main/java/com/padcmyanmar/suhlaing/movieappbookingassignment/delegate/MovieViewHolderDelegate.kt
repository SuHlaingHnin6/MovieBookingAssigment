package com.padcmyanmar.suhlaing.movieappbookingassignment.delegate

interface MovieViewHolderDelegate {
    fun onTapMovie()
}